// 1 | 2 | 3
export type SerumVersion = 3
