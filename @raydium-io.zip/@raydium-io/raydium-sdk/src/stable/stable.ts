import { Liquidity } from '../liquidity'

export class Stable extends Liquidity {}
