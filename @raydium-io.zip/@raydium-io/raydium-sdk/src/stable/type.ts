// 1
export type StableVersion = 1
