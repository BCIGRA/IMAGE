export const version = '1.1.0-beta.6'
