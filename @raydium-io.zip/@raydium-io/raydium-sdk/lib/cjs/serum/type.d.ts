export type SerumVersion = 3;
