import { ComputeBudgetConfig, InnerTransaction } from '../base';
export declare function addComputeBudget(config: ComputeBudgetConfig): {
    address: {};
    innerTransaction: InnerTransaction;
};
