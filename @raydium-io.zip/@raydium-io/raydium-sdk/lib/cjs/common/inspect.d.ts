export declare function inspectPublicKey(): void;
export declare function inspectBN(): void;
export declare function inspectAll(): void;
