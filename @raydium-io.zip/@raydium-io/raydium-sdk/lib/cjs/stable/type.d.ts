export type StableVersion = 1;
