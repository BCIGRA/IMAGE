import { Liquidity } from '../liquidity';
export declare class Stable extends Liquidity {
}
