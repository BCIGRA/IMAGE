export declare const MAINNET_OFFICIAL_LIQUIDITY_POOLS: string[];
export declare const TESTNET_OFFICIAL_LIQUIDITY_POOLS: never[];
export declare const DEVNET_OFFICIAL_LIQUIDITY_POOLS: never[];
