import { FarmPoolBaseInfo } from './type';
export declare const MAINNET_FARM_POOLS: FarmPoolBaseInfo[];
export declare const TESTNET_FARM_POOLS: FarmPoolBaseInfo[];
export declare const DEVNET_FARM_POOLS: FarmPoolBaseInfo[];
