import { LpTokens, SplTokens } from './type';
export declare const TESTNET_SPL_TOKENS: SplTokens;
export declare const TESTNET_LP_TOKENS: LpTokens;
