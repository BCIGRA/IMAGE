import { NativeTokenInfo, SplTokenInfo } from './type';
export declare const SOL: NativeTokenInfo;
export declare const WSOL: SplTokenInfo;
