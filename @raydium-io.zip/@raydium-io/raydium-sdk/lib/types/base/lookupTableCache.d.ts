import { CacheLTA } from '../common';
export declare const LOOKUP_TABLE_CACHE: CacheLTA;
//# sourceMappingURL=lookupTableCache.d.ts.map