export type StableVersion = 1;
//# sourceMappingURL=type.d.ts.map