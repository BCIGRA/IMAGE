import { Liquidity } from '../liquidity';
export declare class Stable extends Liquidity {
}
//# sourceMappingURL=stable.d.ts.map