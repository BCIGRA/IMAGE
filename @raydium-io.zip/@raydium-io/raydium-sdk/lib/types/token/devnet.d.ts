import { LpTokens, SplTokens } from './type';
export declare const DEVNET_SPL_TOKENS: SplTokens;
export declare const DEVNET_LP_TOKENS: LpTokens;
//# sourceMappingURL=devnet.d.ts.map