import { LpTokens, SplTokens } from './type';
export declare const MAINNET_SPL_TOKENS: SplTokens;
export declare const MAINNET_LP_TOKENS: LpTokens;
//# sourceMappingURL=mainnet.d.ts.map