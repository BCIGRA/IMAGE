export type SerumVersion = 3;
//# sourceMappingURL=type.d.ts.map