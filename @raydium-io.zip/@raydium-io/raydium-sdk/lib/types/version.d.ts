export declare const version = "1.1.0-beta.6";
//# sourceMappingURL=version.d.ts.map